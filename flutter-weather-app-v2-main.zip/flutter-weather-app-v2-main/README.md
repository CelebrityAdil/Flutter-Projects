# Flutter Weather App Version 2.0

Search, Fetch and display real-time data from any city in the World using a free weather API.

# Get Started

i. Create and verify a free account at https://www.weatherapi.com/.
ii. Copy Paste the API Key into the Project
iii. Rub pub dev to import the external packages
iv. Allow internet connection to the device for Android Users

# YouTube Tutorial

https://www.youtube.com/watch?v=aqv8EelqczM


![Asset 51@4x-8](https://user-images.githubusercontent.com/102694446/170826625-a467462e-e321-4685-bbd0-af732b23dfe0.jpg)
